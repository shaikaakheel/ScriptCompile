using Microsoft.SqlServer.Dts.Pipeline;
using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Tasks.ScriptTask;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSIS_Package_ScriptCompile
{
    public sealed class ScriptCompile
    {
        Application _Application = new Application();
        internal Package _Package;
        internal Executables _Executables;
        internal string _PackagePath;
        public ScriptCompile(string PackagePath)
        {
            this._PackagePath = PackagePath;
            Runtime();
        }
        internal void Build(TaskHost _TaskHost)
        {
            if (_TaskHost.InnerObject.ToString().Equals("Microsoft.SqlServer.Dts.Tasks.ScriptTask.ScriptTask"))
            {
                ScriptTask task = (ScriptTask)_TaskHost.InnerObject;
                task.ScriptingEngine.LoadProjectFromStorage();
                task.ScriptingEngine.VstaHelper.Build("");
                task.ScriptingEngine.SaveProjectToStorage();
                task.ScriptingEngine.DisposeVstaHelper();
                _Package.SaveToXML(out string xml, null);
                File.WriteAllText(_PackagePath, xml);
            }
            else if (_TaskHost.InnerObject is Microsoft.SqlServer.Dts.Pipeline.Wrapper.MainPipe)
            {
                MainPipe pipe = (MainPipe)_TaskHost.InnerObject;
                foreach (IDTSComponentMetaData100 comp in pipe.ComponentMetaDataCollection)
                {
                    if (comp.Name == "Script Component")
                    {
                        CManagedComponentWrapper compWrap = comp.Instantiate();
                        ScriptComponentHost scriptComp = (compWrap as IDTSManagedComponent100).InnerObject as ScriptComponentHost;
                        scriptComp.LoadScriptFromComponent();
                        scriptComp.CurrentScriptingEngine.LoadProjectFromStorage();
                        scriptComp.SaveScriptProject();
                        scriptComp.CurrentScriptingEngine.DisposeVstaHelper();
                        _Package.SaveToXML(out string xml, null);
                        File.WriteAllText(_PackagePath, xml);
                    }
                }
            }
        }
        internal void Runtime()
        {
            _Package = _Application.LoadPackage(_PackagePath, null);
            _Executables = _Package.Executables;
            foreach (Executable exe in _Executables)
            {

                switch (exe.GetType().Name)
                {

                    case "TaskHost":
                        {
                            TaskHost taskHost = (TaskHost)exe;
                            Build(taskHost);
                            break;
                        }
                    case "Sequence":
                        {
                            Executables seqExecs = ((Microsoft.SqlServer.Dts.Runtime.Sequence)(exe)).Executables;

                            foreach (Executable seqExec in seqExecs)
                            {
                                switch (seqExec.GetType().Name)
                                {
                                    case "TaskHost":
                                        {
                                            TaskHost taskHost = (TaskHost)seqExec;
                                            Build(taskHost);
                                            break;
                                        }
                                }
                            }
                            break;
                        }
                    case "ForLoop":
                        {
                            Executables seqExecs = ((Microsoft.SqlServer.Dts.Runtime.ForLoop)(exe)).Executables;
                            foreach (Executable seqExec in seqExecs)
                            {
                                switch (seqExec.GetType().Name)
                                {
                                    case "TaskHost":
                                        {
                                            TaskHost taskHost = (TaskHost)seqExec;
                                            Build(taskHost);
                                            break;
                                        }
                                }
                            }
                            break;
                        }
                    case "ForEachLoop":
                        {
                            Executables seqExecs = ((Microsoft.SqlServer.Dts.Runtime.ForEachLoop)(exe)).Executables;

                            foreach (Executable seqExec in seqExecs)
                            {
                                switch (seqExec.GetType().Name)
                                {
                                    case "TaskHost":
                                        {
                                            TaskHost taskHost = (TaskHost)seqExec;
                                            Build(taskHost);
                                            break;
                                        }
                                }
                            }
                            break;
                        }
                }
            }

        }
    }
}