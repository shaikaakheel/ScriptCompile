﻿using ScriptCompile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
         Aakheel a = new Aakheel(@"C:\Users\AShaik\source\ssislibrary\working\Testing\SamplePackages\arthematic - Copy - Copy\arthematic\Package.dtsx");
         Console.WriteLine("completed");
         Console.ReadLine();

        }
    }
}
